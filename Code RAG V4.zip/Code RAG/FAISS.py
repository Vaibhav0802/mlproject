import os
from langchain_community.document_loaders import TextLoader
from langchain_openai import AzureChatOpenAI,AzureOpenAIEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS


os.environ["AZURE_OPENAI_API_KEY"] = "dfb58f8ff710406aab6350cdc9e7e38f"
os.environ["AZURE_OPENAI_ENDPOINT"] = "https://cs-lab-azureopenai.openai.azure.com/"

embeddings = AzureOpenAIEmbeddings(
azure_deployment="embedding",
openai_api_version="2023-05-15",
)
# # Load the document, split it into chunks, embed each chunk and load it into the vector store.
raw_documents = TextLoader("Scenario Data.txt").load()
text_splitter = RecursiveCharacterTextSplitter(chunk_size=800, chunk_overlap=50)
documents = text_splitter.split_documents(raw_documents)
db = FAISS.from_documents(documents, embeddings)
db.save_local("db_scenario")

db=FAISS.load_local("C:/Users/vaibhav.mukhi/Documents/RAG API/rag_llm_api 4/Code RAG/db_scenario/",embeddings,allow_dangerous_deserialization=True)
doc=db.similarity_search_with_relevance_scores("Then the document from the document vault should be downloaded successfully",k=2)
string=(doc[0][0].page_content+"\n"+doc[1][0].page_content)
print(string)