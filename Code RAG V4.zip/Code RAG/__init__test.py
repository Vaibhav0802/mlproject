import os
import getpass
from langchain_community.document_loaders import TextLoader
from langchain_openai import AzureChatOpenAI,AzureOpenAIEmbeddings
from langchain_openai import OpenAIEmbeddings
from langchain_text_splitters import CharacterTextSplitter
from langchain_community.vectorstores import FAISS
import streamlit as st
from langchain.vectorstores import AzureSearch

def initialise_session_state():
    if 'Generate' not in st.session_state:
        st.session_state['Generate'] = False


def set_state():
    st.session_state['Generate']=True

def testcase_to_gherkin(llm,test_case):

# gherkins inside the scenario should not be repetitive. For example user login should not be discussed again. Ensure to include a Gherkin 'Background'
    final_prompt = f""" Act as a quality analyst who is highly experienced in Behaviour Driven Development (BDD) and developing well-constructed Gherkin scenarios fropm test cases. Deeply analyse {test_case}
    Carefully, consider the below instructions.

    1. Use Gherkin BDD language and strictly consider the product information while producing gherkin steps.
    2. Strictly analyse the test cases and produce only single scenario outline and all gherkins should be strictly inside single scenario outline. 
    3. Given, When, And, Then are the core keywords of gherkin. Strictly, make sure to generate single gherkin step corresponding to a test case step.
    4. Strictly ensure the total number of Gherkin steps is fewer than the original test case steps by merging related steps where possible.
    
    Note: The gherkins steps starting with Given, When, And, Then should strictly not exceed the total number of test case steps: {test_case}
    """
    gherkin_steps = llm.predict(final_prompt)
    return gherkin_steps

def db_creation(File_path):
    os.environ["AZURE_OPENAI_API_KEY"] = "dfb58f8ff710406aab6350cdc9e7e38f"
    os.environ["AZURE_OPENAI_ENDPOINT"] = "https://cs-lab-azureopenai.openai.azure.com/"

    embeddings = AzureOpenAIEmbeddings(
    azure_deployment="embedding",
    openai_api_version="2023-05-15",
    )
    # Load the document, split it into chunks, embed each chunk and load it into the vector store.
    raw_documents = TextLoader(File_path).load()
    text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=50)
    documents = text_splitter.split_documents(raw_documents)
    db = FAISS.from_documents(documents, embeddings)
    return db

def get_similar_content(query,db):
    k=2
    results=db.similarity_search_with_relevance_scores(query,k)
    content=""
    for i in range(0,k):
        content+=results[i][0].page_content+"\n\n"

    return content

def get_similar_content_summary(query,db):
    k=1
    results=db.similarity_search_with_relevance_scores(query,k)
    content=""
    for i in range(0,k):
        content+=results[i][0].page_content+"\n\n"

    return content

def get_response(llm,query,content):
    final_prompt = f"""You are an experienced tester. You need to figure out the which code snippet is best suited for the given operation "{query}". Strictly, follow the given instructions while selecting and framing from the provided code snippets.

    1. The provided code snippet should be a Java method designed for Cucumber test scenarios.
    2. Do not generate any code, just pick up the code from the provided code
    {content}
    3. Check the sentiment analysis of the given query with the content provided and stricly pick up the relevant chunks for Cucumber test scenarios.
    4. Do not write "The best suited code snippet" or anything like that. Just begin with the code directly.
    """
    response = llm.predict(final_prompt)
    return response

def get_response_page_func(llm,step_func_answer,page_func_content,summary_content):
    final_prompt = f"""You are an experienced UI automation tester and have knowledge of frameworks like cucumber. You need to extract the suitable page function strictly from Page Functions : {page_func_content} only against the step function: {step_func_answer},  and follow the below instructions carefully.

    1. The provided code snippet should be a Java method designed for Cucumber framework.
    2. Strictly, just pickup the code from Page Functions. If there is no suitable match, just answer none.
    3. For framing the response carefully consider the summary : {summary_content} which tells us about the relationship between step function and page function.
    4. Check the sentiments of the given page function and summary provided to you and strictly pick up the relevant chunks for exact page_functions.
    5. There should not be any explanatory lines while providing the code as a response.
    """
    response = llm.predict(final_prompt)
    return response

def get_response_pages(llm,query,content):
    final_prompt = f"""You are an experienced tester. You need to figure out the which code snippet is best suited for the given operation "{query}". Strictly, follow the given instructions while selecting and framing from the provided code snippets.
    
    1. The provided code snippet should be a Java method designed for Cucumber test scenarios.
    2. First check the sentiment analysis of the given query with the content: {content} provided and if available stricly pick up the relevant chunks for Cucumber test scenarios.
    3. If content provided do not have anything relevant then generate the code snippet according to your intelligence which will be relevant to my query.
    4. The output should stricly contain the code snippet and nothing else.
    """
    response = llm.predict(final_prompt)
    return response


def get_step_function(llm,query,db):
    content=get_similar_content(query,db)
    response=get_response(llm,query,content)
    return response

def get_page_function(llm,step_func_answer,db_pages,db_summary):
    page_func_content=get_similar_content(step_func_answer,db_pages)
    combined_content=step_func_answer+"\n\n"+page_func_content
    summary_content=get_similar_content_summary(combined_content,db_summary)
    response=get_response_page_func(llm,step_func_answer,page_func_content,summary_content)
    return response


def gherkinstep_to_list(gherkin_steps):
    gherkin_split=gherkin_steps.split("\n")
    list_of_gherkins=[]
    for line in gherkin_split:
        line=line.strip()
        line.replace('','')
        if line.startswith("Given"):
            list_of_gherkins.append(line[6:])
        elif line.startswith("When"):
            list_of_gherkins.append(line[5:])
        elif line.startswith("Then"):
            list_of_gherkins.append(line[5:])
        elif line.startswith("And"):
            list_of_gherkins.append(line[4:])
    
    for i in list_of_gherkins:
        print(i)
    return list_of_gherkins

def hit_fallback(llm,query,db_pages):
    content=get_similar_content(query,db_pages)
    response=get_response_pages(llm,query,content)
    return response

def run_pipeline(test_case,db,db_pages,db_summary,db_product):
    llm =  AzureChatOpenAI(
                openai_api_version="2023-09-15-preview",
                deployment_name="inc-gpt-4-32k",
                openai_api_key="8f74251696ce45698eb95495269f3d8c",
                azure_endpoint="https://cs-lab-azureopenai-gpt4.openai.azure.com",
                temperature=0,n=5)
    gherkin_steps=testcase_to_gherkin(llm,test_case,db_product)
    print("---------------------------------gherkin steps--------------------")
    print(gherkin_steps)
    breakpoint()
    list_of_gherkins=gherkinstep_to_list(gherkin_steps)
    code=""
    for query in list_of_gherkins:
        answer=get_step_function(llm,query,db)
        answer_pages=get_page_function(llm,answer,db_pages,db_summary)
        code+="#"+query+"\n\n"+"STEP FUNCTION"+"\n"+answer+"\n\n"+"PAGE FUNCTION"+"\n"+answer_pages+"\n\n"
        # if answer.lower().find("none ")==-1:
        #     code+="#"+query+"\n"+answer+"\n\n"
        # else:
        #     answer=hit_fallback(llm,query,db_pages)
        #     code+="## Fallback Approach\n"
        #     code+="#"+query+"\n"+answer+"\n\n"
    print("-------------------------------Code-------------------------------------")
    print(code)
    return code

def main():
    initialise_session_state()
    st.set_page_config(layout="wide")
    st.markdown("<h1 style='text-align: center; color: black; font-size: 40px; font-weight: bold; margin-top: 0;'>Code RAG</h1>", unsafe_allow_html=True)
    st.sidebar.markdown("<h1 style='text-align: left; color: black; font-size: 22px; margin-top: 0;'>Please enter the test cases here:</h1>", unsafe_allow_html=True)
    test_case = st.sidebar.text_area("", height=350)
    st.sidebar.markdown("<br>", unsafe_allow_html=True)
    os.environ["AZURE_OPENAI_API_KEY"] = "dfb58f8ff710406aab6350cdc9e7e38f"
    os.environ["AZURE_OPENAI_ENDPOINT"] = "https://cs-lab-azureopenai.openai.azure.com/"

    embeddings = AzureOpenAIEmbeddings(
    azure_deployment="embedding",
    openai_api_version="2023-05-15",
    )
    
    if ('db' not in st.session_state) and ('db_pages' not in st.session_state) and ('db_summary' not in st.session_state):
        st.session_state['db']=FAISS.load_local("C:/Users/vaibhav.mukhi/Documents/RAG API/rag_llm_api 4/Code RAG/db_steps/",embeddings,allow_dangerous_deserialization=True)
        st.session_state['db_pages']=FAISS.load_local("C:/Users/vaibhav.mukhi/Documents/RAG API/rag_llm_api 4/Code RAG/db_pages/",embeddings,allow_dangerous_deserialization=True)
        st.session_state['db_summary']=FAISS.load_local("C:/Users/vaibhav.mukhi/Documents/RAG API/rag_llm_api 4/Code RAG/db_summary/",embeddings,allow_dangerous_deserialization=True)
        
    st.sidebar.button("Generate Code", on_click=set_state)
    if st.session_state['Generate']:
        Final_code=run_pipeline(test_case,st.session_state['db'],st.session_state['db_pages'],st.session_state['db_summary'])
        st.markdown("<h1 style='text-align: center; color: #878382; font-size: 22px; font-weight: bold; margin-top: 0;'>Here is the code for test cases:</h1>", unsafe_allow_html=True)
        st.code(Final_code,language="python")
    st.session_state['Generate'] = False
    

if __name__ == "__main__":
    main()



