# import streamlit as st

# def initialise_session_state():
#     if 'Generate' not in st.session_state:
#         st.session_state['Generate'] = False

# def set_state():
#     st.session_state['Generate']=True

# def get_code(test_case):
#     return test_case

# def main():
#     initialise_session_state()
#     st.markdown("<h1 style='text-align: center; color: black; font-size: 40px; font-weight: bold; margin-top: 0;'>Code RAG</h1>", unsafe_allow_html=True)
#     st.sidebar.markdown("<h1 style='text-align: left; color: black; font-size: 22px; margin-top: 0;'>Please enter the test cases here:</h1>", unsafe_allow_html=True)
#     test_case = st.sidebar.text_area("", height=350)
#     test_cases_list=test_case.split("\n")
#     st.sidebar.markdown("<br>", unsafe_allow_html=True)
#     st.sidebar.button("Generate Code", on_click=set_state)
#     if st.session_state['Generate']:
#         st.markdown("<h1 style='text-align: center; color: #878382; font-size: 22px; font-weight: bold; margin-top: 0;'>Here is the code for test cases:</h1>", unsafe_allow_html=True)
#         st.code(test_case,language="python")


# if __name__ == "__main__":
#     main()

import os
import getpass
from langchain_community.document_loaders import TextLoader
from langchain_openai import AzureChatOpenAI,AzureOpenAIEmbeddings
from langchain_openai import OpenAIEmbeddings
from langchain_text_splitters import CharacterTextSplitter
from langchain_community.vectorstores import FAISS
import streamlit as st

def initialise_session_state():
    if 'Generate' not in st.session_state:
        st.session_state['Generate'] = False

def set_state():
    st.session_state['Generate']=True

def testcase_to_gherkin(llm,test_case):
    final_prompt = f""" Act as a quality analyst who is highly experienced in behavioural driven development and developing well-constructed Gherkin Scenarios from {test_case}.
    When I supply a test case, I want you to create full coverage in the following way:

    1. Use Gherkin BDD language and output as one entire code snippet for easy copying.
    2. Ensure to include a Gherkin 'Background'
    3. Ensure 'Background" is provided only once and is placed after the user story and before the scenario.
    4. Ensure to include only Given, When, And, Then statements with their incorporating descriptive tags for enhanced clarity and organization.
    5.Ensure to include only necessary statements and strictly remove the useless lines.
    6. Ensure variables are added to a Gherkin 'Examples' table appropriately to facilitate parameterization and data-driven testing.
    7. Do not assume any output like error messages or variables not part of the requirements.
    """
    gherkin_steps = llm.predict(final_prompt)
    return gherkin_steps

def db_creation(File_path):
    os.environ["AZURE_OPENAI_API_KEY"] = "dfb58f8ff710406aab6350cdc9e7e38f"
    os.environ["AZURE_OPENAI_ENDPOINT"] = "https://cs-lab-azureopenai.openai.azure.com/"

    embeddings = AzureOpenAIEmbeddings(
    azure_deployment="embedding",
    openai_api_version="2023-05-15",
    )
    # Load the document, split it into chunks, embed each chunk and load it into the vector store.
    raw_documents = TextLoader(File_path).load()
    text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=50)
    documents = text_splitter.split_documents(raw_documents)
    db = FAISS.from_documents(documents, embeddings)
    return db

def get_similar_content(query,db):

    docs = db.similarity_search(query)
    results=db.similarity_search_with_relevance_scores(query,k=2)
    k=2
    content=""
    for i in range(0,k):
        content+=results[i][0].page_content+"\n\n"

    return content


def get_response(llm,query,content):
    final_prompt = f"""You are an experienced tester. You need to figure out the which code snippet is best suited for the given operation "{query}". Strictly, follow the given instructions while selecting and framing from the provided code snippets.

    1. The provided code snippet should be a Java method designed for Cucumber test scenarios.
    2. Do not generate any code, just pick up the code from the provided code
    {content}
    3. Check the sentiment analysis of the given query with the content provided and stricly pick up the relevant chunks for Cucumber test scenarios.
    4. Do not write "The best suited code snippet" or anything like that. Just begin with the code directly.
    """
    response = llm.predict(final_prompt)
    return response


def get_response_pages(llm,query,content):
    final_prompt = f"""You are an experienced tester. You need to figure out the which code snippet is best suited for the given operation "{query}". Strictly, follow the given instructions while selecting and framing from the provided code snippets.
    
    1. The provided code snippet should be a Java method designed for Cucumber test scenarios.
    2. First check the sentiment analysis of the given query with the content: {content} provided and if available stricly pick up the relevant chunks for Cucumber test scenarios.
    3. If content provided do not have anything relevant then generate the code snippet according to your intelligence which will be relevant to my query.
    4. The output should stricly contain the code snippet and nothing else.
    """
    response = llm.predict(final_prompt)
    return response


def get_gherkin_step(llm,query,db):
    
    content=get_similar_content(query,db)
    response=get_response(llm,query,content)
    return response

def gherkinstep_to_list(gherkin_steps):
    gherkin_split=gherkin_steps.split("\n")
    list_of_gherkins=[]
    for line in gherkin_split:
        line=line.strip()
        line.replace('','')
        if line.startswith("Given"):
            list_of_gherkins.append(line[6:])
        elif line.startswith("When"):
            list_of_gherkins.append(line[5:])
        elif line.startswith("Then"):
            list_of_gherkins.append(line[5:])
        elif line.startswith("And"):
            list_of_gherkins.append(line[4:])
    
    for i in list_of_gherkins:
        print(i)
    return list_of_gherkins

def hit_fallback(llm,query,db_pages):
    content=get_similar_content(query,db_pages)
    response=get_response_pages(llm,query,content)
    return response

def run_pipeline(gherkin_steps):
    llm =  AzureChatOpenAI(
                openai_api_version="2023-09-15-preview",
                deployment_name="inc-gpt-4-32k",
                openai_api_key="8f74251696ce45698eb95495269f3d8c",
                azure_endpoint="https://cs-lab-azureopenai-gpt4.openai.azure.com",
                temperature=0,n=5)
    # gherkin_steps=testcase_to_gherkin(llm,test_case)
    print("---------------------------------gherkin steps--------------------")
    print(gherkin_steps)
    list_of_gherkins=gherkinstep_to_list(gherkin_steps)
    code=""
    db=db_creation("Data File.txt")
    # db_pages=db_creation("Final Data Pages.txt")
    for query in list_of_gherkins:
        answer=get_gherkin_step(llm,query,db)
        code+="#"+query+"\n"+answer+"\n\n"
        # if answer.lower().find("none ")==-1:
        #     code+="#"+query+"\n"+answer+"\n\n"
        # else:
        #     answer=hit_fallback(llm,query,db_pages)
        #     code+="## Fallback Approach\n"
        #     code+="#"+query+"\n"+answer+"\n\n"
    print("-------------------------------Code-------------------------------------")
    print(code)
    return code

def main():
    initialise_session_state()
    st.set_page_config(layout="wide")
    st.markdown("<h1 style='text-align: center; color: black; font-size: 40px; font-weight: bold; margin-top: 0;'>Code RAG</h1>", unsafe_allow_html=True)
    st.sidebar.markdown("<h1 style='text-align: left; color: black; font-size: 22px; margin-top: 0;'>Please enter the test cases here:</h1>", unsafe_allow_html=True)
    test_case = st.sidebar.text_area("", height=350)
    st.sidebar.markdown("<br>", unsafe_allow_html=True)
    st.sidebar.button("Generate Code", on_click=set_state)
    if st.session_state['Generate']:
        Final_code=run_pipeline(test_case)
        st.markdown("<h1 style='text-align: center; color: #878382; font-size: 22px; font-weight: bold; margin-top: 0;'>Here is the code for test cases:</h1>", unsafe_allow_html=True)
        st.code(Final_code,language="python")

if __name__ == "__main__":
    main()



